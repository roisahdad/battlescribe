#!/bin/sh
jre/bin/java -Xms1024m -jar DataIndexer.jar
