#!/bin/sh
jre/bin/java -Xms1024m -jar DataEditor.jar
