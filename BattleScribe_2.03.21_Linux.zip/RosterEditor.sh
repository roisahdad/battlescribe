#!/bin/sh
jre/bin/java -Xms1024m -jar RosterEditor.jar
